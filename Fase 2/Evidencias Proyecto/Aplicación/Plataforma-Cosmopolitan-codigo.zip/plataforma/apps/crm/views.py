"""Panel interno de la agencia (CRM comercial). Solo para el equipo (usuarios staff).

Todo sale de la base: prospectos, interacciones, cotizaciones, tareas y clientes.
Sin datos, cada bloque muestra su estado vacío (no hay datos de ejemplo).
"""

import csv
from datetime import date, timedelta

from django.conf import settings
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth import get_user_model
from django.http import FileResponse, Http404, HttpResponse, JsonResponse, request
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST
from django.db import transaction
from django.utils.text import slugify
from django.urls import reverse, reverse_lazy

from apps.accounts.decorators import requiere_administradora, requiere_equipo
from apps.accounts import activacion
from apps.accounts.forms import InvitacionClienteForm, UsuarioForm
from apps.accounts.models import Rol
from apps.ai.services import ErrorIA, IANoConfigurada, generar_diagnostico_cotizacion, reescribir_texto
from apps.catalog.models import Plan, Servicio
from apps.clients.forms import ClienteFichaForm, DocumentoClienteForm, KPIForm, MedicionForm
from apps.clients.models import Cliente, DocumentoCliente, KPICliente, MedicionKPI
from apps.core.access import clientes_visibles, obtener_cliente_visible, puede_aprobar
from apps.core.middleware import SESSION_CLIENT_KEY
from apps.core.models import RegistroAuditoria
from allauth.mfa.models import Authenticator

from apps.website.views import cotizacion

from .models import Cotizacion, CotizacionItem, Interaccion, Prospecto, Tarea

from .froms import PlanEntregableFormSet, PlanForm, ProspectoManualForm, ServicioForm
from apps.website.models import ConfiguracionAgencia, Contenido, MetadatosPagina
from apps.website.forms import ConfiguracionAgenciaForm, ContenidoForm, MetadatosPaginaForm

ETAPAS_EMBUDO = [
    Prospecto.Etapa.NUEVO,
    Prospecto.Etapa.DIAGNOSTICO,
    Prospecto.Etapa.COTIZACION_ENVIADA,
    Prospecto.Etapa.NEGOCIACION,
    Prospecto.Etapa.GANADO,
]
ETAPAS_ACTIVAS = ETAPAS_EMBUDO[:-1]
PERIODOS = [("mes", "Este mes"), ("mes_anterior", "Mes anterior"), ("3_meses", "Últimos 3 meses"), ("anio", "Este año")]
MESES_CORTOS = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"]

# Sin sesión: al login. Con sesión y sin acceso (p. ej. un cliente): mensaje y registro en la auditoría (CP-019).
solo_equipo = requiere_equipo


# ── Utilidades ────────────────────────────────────────────────────────────────

def _nombre(usuario):
    return (usuario.get_full_name() or usuario.email or usuario.username) if usuario else None


def _iniciales(usuario):
    partes = _nombre(usuario).replace("@", " ").replace(".", " ").split()
    return "".join(p[0] for p in partes[:2]).upper()


def _equipo():
    return get_user_model().objects.filter(is_staff=True, is_active=True).order_by("first_name", "email")


def _volver(request, por_defecto):
    destino = request.POST.get("next") or request.GET.get("next")
    if destino and url_has_allowed_host_and_scheme(destino, allowed_hosts={request.get_host()}):
        return redirect(destino)
    return redirect(por_defecto)


def _rango_periodo(clave, hoy):
    """(inicio, fin) del período, fin exclusivo."""
    inicio_mes = hoy.replace(day=1)
    siguiente_mes = (inicio_mes + timedelta(days=32)).replace(day=1)
    if clave == "mes_anterior":
        anterior = (inicio_mes - timedelta(days=1)).replace(day=1)
        return anterior, inicio_mes
    if clave == "3_meses":
        inicio = inicio_mes
        for _ in range(2):
            inicio = (inicio - timedelta(days=1)).replace(day=1)
        return inicio, siguiente_mes
    if clave == "anio":
        return date(hoy.year, 1, 1), date(hoy.year + 1, 1, 1)
    return inicio_mes, siguiente_mes


def _en_rango(momento, inicio, fin):
    return momento is not None and inicio <= timezone.localtime(momento).date() < fin


def contexto_panel(request, seccion, **context):
    """Datos comunes del layout del panel: usuario, badges del sidebar y sección activa."""
    u = request.user
    context["panel_usuario"] = {
        "nombre": _nombre(u),
        "cargo": u.get_rol_display() if u.rol else ("Administradora" if u.is_superuser else "Equipo"),
        "iniciales": _iniciales(u),
    }
    context["panel_badges"] = {"prospectos": Prospecto.objects.filter(etapa=Prospecto.Etapa.NUEVO).count()}
    context["panel_clientes"] = list(clientes_visibles(u).filter(activo=True).values("pk", "nombre"))
    context["panel_cliente_activo"] = getattr(request, "client_id", None)
    context["seccion_panel"] = seccion
    return context


def _fila_prospecto(p):
    return {
        "id": p.pk,
        "empresa": p.empresa,
        "nombre": p.nombre,
        "detalle": f"{p.rubro} · {p.region}",
        "etapa": p.etapa,
        "etapa_nombre": p.get_etapa_display(),
        "valor_mensual": p.valor_estimado,
        "plan": p.plan_referencia.nombre if p.plan_referencia else None,
        "responsable": _nombre(p.responsable),
        "dias": p.dias_sin_movimiento,
        "creado_en": p.creado_en,
    }


# ── Dashboard ─────────────────────────────────────────────────────────────────

@solo_equipo
def dashboard(request):
    hoy = timezone.localdate()
    periodo = request.GET.get("periodo") if request.GET.get("periodo") in dict(PERIODOS) else "mes"
    inicio, fin = _rango_periodo(periodo, hoy)
    largo = fin - inicio
    inicio_prev, fin_prev = inicio - largo, inicio

    prospectos = list(Prospecto.objects.select_related("plan_sugerido", "plan_interes", "responsable"))
    cotizaciones = list(Cotizacion.objects.prefetch_related("items"))
    for c in cotizaciones:
        c.t = c.totales()

    # KPIs desde cotizaciones del período.
    def aceptadas_en(a, b):
        return [c for c in cotizaciones if c.estado == Cotizacion.Estado.ACEPTADA and _en_rango(c.respondida_en, a, b)]

    aceptadas = aceptadas_en(inicio, fin)
    rechazadas = [c for c in cotizaciones if c.estado == Cotizacion.Estado.RECHAZADA and _en_rango(c.respondida_en, inicio, fin)]
    enviadas = [c for c in cotizaciones if _en_rango(c.enviada_en, inicio, fin)]
    ingreso = sum(c.t["mensual"] for c in aceptadas)
    ingreso_prev = sum(c.t["mensual"] for c in aceptadas_en(inicio_prev, fin_prev))
    respondidas = len(aceptadas) + len(rechazadas)
    kpis = {
        "ingresos": {
            "valor": ingreso,
            "variacion_pct": round((ingreso - ingreso_prev) / ingreso_prev * 100, 1) if ingreso_prev else None,
        },
        "cotizaciones": {"cantidad": len(enviadas), "monto": sum(c.t["total"] for c in enviadas)},
        "cierre": {
            "tasa_pct": round(len(aceptadas) / respondidas * 100) if respondidas else None,
            "aceptadas": len(aceptadas),
            "rechazadas": len(rechazadas),
            "en_espera": sum(1 for c in cotizaciones if c.estado == Cotizacion.Estado.ENVIADA),
        },
        "ticket": {"valor": round(ingreso / len(aceptadas)) if aceptadas else None},
    }

    # Gráfico: últimos 6 meses, cotizaciones enviadas vs. aceptadas.
    meses = []
    mes = hoy.replace(day=1)
    for _ in range(6):
        meses.insert(0, mes)
        mes = (mes - timedelta(days=1)).replace(day=1)
    grafico = {"meses": [], "enviadas": [], "aceptadas": []}
    for m in meses:
        siguiente = (m + timedelta(days=32)).replace(day=1)
        grafico["meses"].append(MESES_CORTOS[m.month - 1])
        grafico["enviadas"].append(sum(1 for c in cotizaciones if _en_rango(c.enviada_en, m, siguiente)))
        grafico["aceptadas"].append(len(aceptadas_en(m, siguiente)))
    hay_grafico = any(grafico["enviadas"]) or any(grafico["aceptadas"])

    # Embudo: estado actual de todos los prospectos.
    embudo = []
    for etapa in ETAPAS_EMBUDO:
        de_la_etapa = [p for p in prospectos if p.etapa == etapa]
        embudo.append({
            "etapa": etapa.value, "nombre": etapa.label, "cantidad": len(de_la_etapa),
            "monto": sum(p.valor_estimado or 0 for p in de_la_etapa),
        })
    maximo = max(f["cantidad"] for f in embudo) or 1
    for fila in embudo:
        fila["ancho_pct"] = round(fila["cantidad"] / maximo * 100)

    # Origen de los prospectos del período: 3 principales + "Otros" (paleta validada de 4 colores).
    del_periodo = [p for p in prospectos if _en_rango(p.creado_en, inicio, fin)]
    conteo = {}
    for p in del_periodo:
        # Lo que declaró; si no indicó nada, la fuente medida de la campaña (UTM, PC-CAP-01).
        clave = p.get_como_nos_conocio_display() or (p.utm_source.capitalize() if p.utm_source else "No indicó")
        conteo[clave] = conteo.get(clave, 0) + 1
    orden = sorted(conteo.items(), key=lambda x: -x[1])
    origenes = [{"origen": n, "cantidad": c} for n, c in orden[:3]]
    if len(orden) > 3:
        origenes.append({"origen": "Otros", "cantidad": sum(c for _, c in orden[3:])})
    for o in origenes:
        o["pct"] = round(o["cantidad"] / len(del_periodo) * 100)

    requieren_accion = sorted((p for p in prospectos if p.etapa in ETAPAS_ACTIVAS), key=lambda p: p.actualizado_en)[:5]
    tareas = Tarea.objects.select_related("responsable", "prospecto").filter(completada=False)[:8]

    context = contexto_panel(
        request,
        "dashboard",
        fecha_hoy=hoy,
        periodos=PERIODOS,
        periodo_actual=periodo,
        periodo_nombre=dict(PERIODOS)[periodo],
        kpis=kpis,
        embudo=embudo,
        hay_prospectos=bool(prospectos),
        grafico_cotizaciones=grafico,
        hay_grafico=hay_grafico,
        tabla_cotizaciones=[
            {"mes": m, "enviadas": e, "aceptadas": a}
            for m, e, a in zip(grafico["meses"], grafico["enviadas"], grafico["aceptadas"])
        ],
        prospectos_accion=[_fila_prospecto(p) for p in requieren_accion],
        dias_alerta=3,  # el Alcance compromete cotizar en 3 días hábiles
        tareas=[
            {
                "id": t.pk, "titulo": t.titulo, "fecha": t.fecha, "vencida": bool(t.fecha and t.fecha < hoy),
                "es_hoy": t.fecha == hoy, "responsable": _iniciales(t.responsable) if t.responsable else None,
                "responsable_nombre": _nombre(t.responsable), "prospecto": t.prospecto,
            }
            for t in tareas
        ],
        equipo=_equipo(),
        origenes=origenes,
    )
    return render(request, "crm/dashboard.html", context)


# ── Tareas ────────────────────────────────────────────────────────────────────

@solo_equipo
@require_POST
def tarea_crear(request):
    titulo = request.POST.get("titulo", "").strip()
    if not titulo:
        messages.error(request, "Escribe un título para la tarea.")
        return _volver(request, "crm:dashboard")
    responsable = _equipo().filter(pk=request.POST.get("responsable") or None).first()
    prospecto = Prospecto.objects.filter(pk=request.POST.get("prospecto") or None).first()
    try:
        fecha = date.fromisoformat(request.POST.get("fecha", ""))
    except ValueError:
        fecha = None
    Tarea.objects.create(titulo=titulo[:160], fecha=fecha, responsable=responsable, prospecto=prospecto, creado_por=request.user)
    messages.success(request, "Tarea creada.")
    return _volver(request, "crm:dashboard")


@solo_equipo
@require_POST
def tarea_alternar(request, pk):
    tarea = get_object_or_404(Tarea, pk=pk)
    tarea.completada = not tarea.completada
    tarea.completada_en = timezone.now() if tarea.completada else None
    tarea.save(update_fields=["completada", "completada_en"])
    return _volver(request, "crm:dashboard")


# ── Prospectos ────────────────────────────────────────────────────────────────

def _prospectos_filtrados(request):
    lista = Prospecto.objects.select_related("plan_sugerido", "plan_interes", "responsable")
    etapa = request.GET.get("etapa", "")
    if etapa in Prospecto.Etapa.values:
        lista = lista.filter(etapa=etapa)
    q = request.GET.get("q", "").strip()
    if q:
        lista = lista.filter(Q(nombre__icontains=q) | Q(empresa__icontains=q) | Q(correo__icontains=q))
    return lista, etapa, q


@solo_equipo
def prospectos(request):
    lista, etapa, q = _prospectos_filtrados(request)
    vista = "kanban" if request.GET.get("vista") == "kanban" else "lista"
    filas = [_fila_prospecto(p) for p in lista]
    columnas = []
    if vista == "kanban":
        # El kanban muestra todas las etapas a la vez; el filtro por etapa solo aplica a la lista.
        todos = [_fila_prospecto(p) for p in _prospectos_filtrados_sin_etapa(q)]
        columnas = [
            {"clave": clave, "nombre": nombre, "prospectos": [f for f in todos if f["etapa"] == clave]}
            for clave, nombre in Prospecto.Etapa.choices
        ]
    context = contexto_panel(
        request,
        "prospectos",
        prospectos=filas,
        columnas=columnas,
        vista=vista,
        q=q,
        etapas=Prospecto.Etapa.choices,
        etapa_activa=etapa,
        total=Prospecto.objects.count(),
    )
    return render(request, "crm/prospectos.html", context)


def _prospectos_filtrados_sin_etapa(q):
    lista = Prospecto.objects.select_related("plan_sugerido", "plan_interes", "responsable")
    if q:
        lista = lista.filter(Q(nombre__icontains=q) | Q(empresa__icontains=q) | Q(correo__icontains=q))
    return lista


@solo_equipo
@require_POST
def prospecto_mover(request, pk):
    """Cambia la etapa de un prospecto (kanban: arrastrar y soltar o selector de cada tarjeta)."""
    prospecto = get_object_or_404(Prospecto, pk=pk)
    nueva = request.POST.get("etapa")
    es_ajax = request.headers.get("X-Requested-With") == "fetch"
    if nueva not in Prospecto.Etapa.values:
        if es_ajax:
            return JsonResponse({"ok": False, "error": "Etapa no válida."}, status=400)
        messages.error(request, "Etapa no válida.")
        return _volver(request, "crm:prospectos")
    _mover_etapa(prospecto, nueva, request.user)
    if es_ajax:
        return JsonResponse({"ok": True, "etapa": prospecto.etapa, "etapa_nombre": prospecto.get_etapa_display()})
    messages.success(request, f"«{prospecto.empresa}» movido a {prospecto.get_etapa_display()}.")
    return _volver(request, "crm:prospectos")


@solo_equipo
def prospectos_exportar(request):
    lista, etapa, _q = _prospectos_filtrados(request)
    respuesta = HttpResponse(content_type="text/csv; charset=utf-8")
    respuesta["Content-Disposition"] = f'attachment; filename="prospectos-{timezone.localdate().isoformat()}.csv"'
    respuesta.write("﻿")  # BOM para que Excel lea bien los acentos
    escritor = csv.writer(respuesta, delimiter=";")
    escritor.writerow([
        "Empresa", "Nombre", "Correo", "Teléfono", "Rubro", "Región", "Tamaño", "Presupuesto", "Objetivos",
        "Plan de interés", "Plan sugerido", "Etapa", "Responsable", "Cómo nos conoció", "Canal",
        "Fuente (UTM)", "Medio (UTM)", "Campaña (UTM)", "Sitio de referencia", "Creado",
    ])
    for p in lista:
        escritor.writerow([
            p.empresa, p.nombre, p.correo, p.telefono, p.rubro, p.region, p.get_tamano_display(), p.get_presupuesto_display(),
            ", ".join(p.objetivos), p.plan_interes.nombre if p.plan_interes else "", p.plan_sugerido.nombre if p.plan_sugerido else "",
            p.get_etapa_display(), _nombre(p.responsable) or "", p.get_como_nos_conocio_display(), p.get_canal_display(),
            p.utm_source, p.utm_medium, p.utm_campaign, p.sitio_referencia,
            timezone.localtime(p.creado_en).strftime("%d-%m-%Y %H:%M"),
        ])
    return respuesta


@solo_equipo
def prospecto_nuevo(request):
    """Registro manual de un prospecto que llegó por otro canal (PC-PRO-02)."""
    duplicados = []
    if request.method == "POST":
        form = ProspectoManualForm(request.POST)
        if form.is_valid():
            duplicados = form.buscar_duplicados()
            if not duplicados or request.POST.get("confirmar_duplicado"):
                prospecto = form.save(commit=False)
                prospecto.canal = Prospecto.Canal.MANUAL
                prospecto.responsable = request.user
                prospecto.save()
                _registrar(
                    prospecto, request.user, "Prospecto registrado manualmente",
                    descripcion=f"Canal de origen: {prospecto.get_como_nos_conocio_display()}",
                )
                messages.success(request, f"Prospecto «{prospecto.empresa}» registrado.")
                return redirect("crm:prospecto_detalle", pk=prospecto.pk)
    else:
        form = ProspectoManualForm()
    context = contexto_panel(request, "prospectos", form=form, duplicados=duplicados)
    return render(request, "crm/prospecto_formulario.html", context)


@solo_equipo
def prospecto_detalle(request, pk):
    prospecto = get_object_or_404(
        Prospecto.objects.select_related("plan_sugerido", "plan_interes", "responsable", "diagnostico_revisado_por", "cliente"),
        pk=pk,
    )

    if request.method == "POST":
        _accion_prospecto(request, prospecto)
        return redirect(request.get_full_path())

    indice_actual = ETAPAS_EMBUDO.index(prospecto.etapa) if prospecto.etapa in ETAPAS_EMBUDO else -1
    progreso_embudo = [
        {"nombre": etapa.label, "estado": "completada" if i < indice_actual else "actual" if i == indice_actual else "pendiente"}
        for i, etapa in enumerate(ETAPAS_EMBUDO)
    ]

    filtros = [("todo", "Todo"), ("correo", "Correos"), ("llamada", "Llamadas"), ("reunion", "Reuniones")]
    filtro = request.GET.get("tipo", "todo")
    interacciones = prospecto.interacciones.select_related("autor")
    if filtro in Interaccion.Tipo.values:
        interacciones = interacciones.filter(tipo=filtro)

    tab = "cotizaciones" if request.GET.get("tab") == "cotizaciones" else "resumen"
    cotizaciones = list(prospecto.cotizaciones.prefetch_related("items"))
    for c in cotizaciones:
        c.t = c.totales()

    context = contexto_panel(
        request,
        "prospectos",
        prospecto=prospecto,
        progreso_embudo=progreso_embudo,
        interacciones=interacciones,
        filtros=filtros,
        filtro_activo=filtro,
        tab=tab,
        cotizaciones=cotizaciones,
        etapas=Prospecto.Etapa.choices,
        tipos_interaccion=[t for t in Interaccion.Tipo.choices if t[0] != Interaccion.Tipo.SISTEMA],
        ia_configurada=bool(settings.AI_API_KEY),
        planes_contratables=Plan.objects.filter(activo=True).order_by("orden", "precio_mensual"),
        plan_por_defecto=prospecto.plan_interes_id or prospecto.plan_sugerido_id,
    )
    return render(request, "crm/prospecto_detalle.html", context)


def _registrar(prospecto, usuario, titulo, tipo=Interaccion.Tipo.SISTEMA, descripcion=""):
    Interaccion.objects.create(prospecto=prospecto, tipo=tipo, titulo=titulo[:160], descripcion=descripcion, autor=usuario)


def _mover_etapa(prospecto, nueva, usuario):
    if nueva == prospecto.etapa:
        return False
    anterior = prospecto.get_etapa_display()
    prospecto.etapa = nueva
    prospecto.save(update_fields=["etapa", "actualizado_en"])
    _registrar(prospecto, usuario, f"Etapa: {anterior} → {prospecto.get_etapa_display()}")
    return True


def _accion_prospecto(request, prospecto):
    accion = request.POST.get("accion")
    usuario = request.user

    if accion == "generar_diagnostico":
        try:
            generar_diagnostico_cotizacion(prospecto, usuario)
            messages.success(request, "Borrador de diagnóstico generado. Revísalo y edítalo antes de usarlo.")
        except IANoConfigurada:
            messages.error(request, "La IA no está configurada: falta AI_API_KEY en el archivo .env.")
        except ErrorIA as e:
            messages.error(request, f"No se pudo generar el diagnóstico. {e}")

    elif accion == "guardar_diagnostico":
        prospecto.diagnostico_ia = request.POST.get("diagnostico", "").strip()
        prospecto.diagnostico_revisado_por = usuario
        prospecto.diagnostico_revisado_en = timezone.now()
        prospecto.save(update_fields=["diagnostico_ia", "diagnostico_revisado_por", "diagnostico_revisado_en", "actualizado_en"])
        messages.success(request, "Diagnóstico guardado y marcado como revisado.")

    elif accion == "cambiar_etapa":
        nueva = request.POST.get("etapa")
        if nueva in Prospecto.Etapa.values and _mover_etapa(prospecto, nueva, usuario):
            messages.success(request, f"Prospecto movido a «{prospecto.get_etapa_display()}».")

    elif accion == "asignarme":
        prospecto.responsable = usuario
        prospecto.save(update_fields=["responsable", "actualizado_en"])
        messages.success(request, "Quedaste como responsable de este prospecto.")

    elif accion == "instagram":
        prospecto.instagram = request.POST.get("instagram", "").strip().lstrip("@")[:60]
        seguidores = request.POST.get("seguidores", "").replace(".", "").strip()
        prospecto.instagram_seguidores = int(seguidores) if seguidores.isdigit() else None
        prospecto.save(update_fields=["instagram", "instagram_seguidores", "actualizado_en"])
        messages.success(request, "Cuenta de Instagram actualizada.")

    elif accion == "registrar_interaccion":
        tipo = request.POST.get("tipo")
        titulo = request.POST.get("titulo", "").strip()
        if tipo in Interaccion.Tipo.values and titulo:
            _registrar(prospecto, usuario, titulo, tipo, request.POST.get("descripcion", "").strip())
            prospecto.save(update_fields=["actualizado_en"])
            messages.success(request, "Interacción registrada.")
        else:
            messages.error(request, "Indica el tipo y un título para la interacción.")

    elif accion == "convertir_cliente":
        if prospecto.cliente:
            messages.info(request, "Este prospecto ya es cliente.")
        else:
            plan = Plan.objects.filter(pk=request.POST.get("plan") or None, activo=True).first()
            if plan is None:
                messages.error(request, "Elige el plan contratado para convertir al prospecto en cliente.")
                return
            inicio_contrato = None
            if request.POST.get("fecha_inicio_contrato"):
                try:
                    inicio_contrato = date.fromisoformat(request.POST["fecha_inicio_contrato"])
                except ValueError:
                    messages.error(request, "La fecha de inicio del contrato no es válida.")
                    return
            objetivos = prospecto.objetivos if isinstance(prospecto.objetivos, list) else []
            with transaction.atomic():
                prospecto.cliente = Cliente.objects.create(
                    nombre=prospecto.empresa,
                    rut=prospecto.rut,
                    rubro=prospecto.rubro,
                    region=prospecto.region,
                    contacto_nombre=prospecto.nombre,
                    contacto_correo=prospecto.correo,
                    contacto_telefono=prospecto.telefono,
                    plan=plan,
                    fecha_inicio_contrato=inicio_contrato,
                    objetivos="\n".join(str(o) for o in objetivos),
                )
                prospecto.save(update_fields=["cliente", "actualizado_en"])
                _mover_etapa(prospecto, Prospecto.Etapa.GANADO, usuario)
                _registrar(prospecto, usuario, f"Convertido en cliente con el plan {plan.nombre}")
            messages.success(
                request,
                f"{prospecto.empresa} ahora es cliente. Cuando confirmen el pago, crea su acceso al portal "
                "desde la ficha del cliente (sección «Acceso al portal»).",
            )


# ── Cotizaciones ──────────────────────────────────────────────────────────────

@solo_equipo
def cotizaciones(request):
    lista = list(Cotizacion.objects.select_related("prospecto").prefetch_related("items"))
    for c in lista:
        c.t = c.totales()
    return render(request, "crm/cotizaciones.html", contexto_panel(request, "cotizaciones", cotizaciones=lista))


@solo_equipo
def cotizacion_nueva(request):
    """GET: elegir prospecto. POST: crea el borrador con el plan y servicios del prospecto y abre el editor."""
    if request.method == "POST":
        prospecto = get_object_or_404(Prospecto, pk=request.POST.get("prospecto") or 0)
        hoy = timezone.localdate()
        cotizacion = Cotizacion.objects.create(
            prospecto=prospecto,
            contacto=f"{prospecto.nombre} · {prospecto.correo}",
            valida_hasta=hoy + timedelta(days=15),
            inicio_estimado=(hoy.replace(day=1) + timedelta(days=32)).replace(day=1),
            diagnostico=prospecto.diagnostico_ia,
            creado_por=request.user,
        )
        if prospecto.plan_referencia:
            _agregar_plan(cotizacion, prospecto.plan_referencia)
        for servicio in prospecto.servicios_requeridos.all():
            _agregar_servicio(cotizacion, servicio)
        _registrar(prospecto, request.user, f"Cotización #{cotizacion.numero} creada (borrador)")
        return redirect("crm:cotizacion_editar", pk=cotizacion.pk)

    context = contexto_panel(
        request,
        "cotizaciones",
        prospectos_opciones=Prospecto.objects.exclude(etapa__in=[Prospecto.Etapa.GANADO, Prospecto.Etapa.PERDIDO]),
        prospecto_inicial=request.GET.get("prospecto", ""),
    )
    return render(request, "crm/cotizacion_nueva.html", context)


def _siguiente_orden(cotizacion):
    return (cotizacion.items.order_by("-orden").values_list("orden", flat=True).first() or 0) + 1


def _agregar_plan(cotizacion, plan):
    CotizacionItem.objects.create(
        cotizacion=cotizacion, plan=plan, descripcion=f"Plan {plan.nombre}", detalle=plan.descripcion[:255],
        valor_unitario=plan.precio_mensual, meses=6, orden=_siguiente_orden(cotizacion),
    )
    if plan.precio_primer_mes and plan.precio_primer_mes > plan.precio_mensual:
        CotizacionItem.objects.create(
            cotizacion=cotizacion, plan=plan, descripcion="Diferencia primer mes", detalle=f"Primer mes del plan {plan.nombre}",
            valor_unitario=plan.precio_primer_mes - plan.precio_mensual, meses=None, orden=_siguiente_orden(cotizacion),
        )


def _agregar_servicio(cotizacion, servicio):
    CotizacionItem.objects.create(
        cotizacion=cotizacion, servicio=servicio, descripcion=servicio.nombre, detalle=servicio.get_modalidad_cobro_display(),
        valor_unitario=servicio.precio, meses=6 if servicio.modalidad_cobro == Servicio.ModalidadCobro.MENSUAL else None,
        orden=_siguiente_orden(cotizacion),
    )


# Rangos permitidos al editar una cotización (provisorios hasta validarlos con la agencia).
CANTIDAD_MIN, CANTIDAD_MAX = 1, 999
MESES_MIN, MESES_MAX = 1, 36
DESCUENTO_MAX = 50


def _guardar_campos(request, cotizacion):
    """Guarda lo editado en el formulario validando rangos permitidos (CP-031, CP-032)."""
    cotizacion.contacto = request.POST.get("contacto", cotizacion.contacto)[:200]
    for campo in ("valida_hasta", "inicio_estimado"):
        try:
            setattr(cotizacion, campo, date.fromisoformat(request.POST.get(campo, "")))
        except ValueError:
            setattr(cotizacion, campo, None)
            
    if request.POST.get("forma_pago") in Cotizacion.FormaPago.values:
        cotizacion.forma_pago = request.POST["forma_pago"]
        
    if request.POST.get("descuento_pct", "").isdigit():
        descuento = int(request.POST["descuento_pct"])
        if 0 <= descuento <= DESCUENTO_MAX:
            cotizacion.descuento_pct = descuento
        else:
            messages.error(request, f"El descuento debe estar entre 0% y {DESCUENTO_MAX}%. Se mantuvo {cotizacion.descuento_pct}%.")
            
    cotizacion.diagnostico = request.POST.get("diagnostico", cotizacion.diagnostico).strip()
    cotizacion.save()
    
    for item in cotizacion.items.all():
        cantidad_raw = request.POST.get(f"cantidad_{item.pk}", "").strip()
        meses_raw = request.POST.get(f"meses_{item.pk}", "").strip()
        
        # CP-032: Validación estricta de cantidad (rechaza 0 o negativas)
        if cantidad_raw:
            try:
                val_cant = int(cantidad_raw)
                if CANTIDAD_MIN <= val_cant <= CANTIDAD_MAX:
                    item.cantidad = val_cant
                else:
                    messages.error(
                        request, 
                        f"Se rechazó la cantidad ({val_cant}) para «{item.descripcion}». El rango permitido es de {CANTIDAD_MIN} a {CANTIDAD_MAX}. El total no fue alterado."
                    )
            except ValueError:
                messages.error(request, f"Cantidad inválida para «{item.descripcion}». El total no fue alterado.")

        if item.meses and meses_raw:
            try:
                val_meses = int(meses_raw)
                if MESES_MIN <= val_meses <= MESES_MAX:
                    item.meses = val_meses
                else:
                    messages.error(
                        request, 
                        f"Se rechazó la duración en meses ({val_meses}) para «{item.descripcion}». El rango permitido es de {MESES_MIN} a {MESES_MAX}."
                    )
            except ValueError:
                messages.error(request, f"Duración en meses inválida para «{item.descripcion}».")
                
        item.save(update_fields=["cantidad", "meses"])


@solo_equipo
def cotizacion_editar(request, pk):
    cotizacion = get_object_or_404(Cotizacion.objects.select_related("prospecto"), pk=pk)
    prospecto = cotizacion.prospecto

    if request.method == "POST":
        # Cada botón envía "accion" o "accion:id" (p. ej. "mas:12"); así el formulario completo viaja con cualquier botón.
        accion, _, valor = request.POST.get("accion", "guardar").partition(":")
        if accion == "agregar_servicio":
            valor = valor or request.POST.get("servicio_agregar", "")
        elif accion == "agregar_plan":
            valor = valor or request.POST.get("plan_agregar", "")
        es_borrador = cotizacion.estado == Cotizacion.Estado.BORRADOR
        if es_borrador:
            _guardar_campos(request, cotizacion)

        if accion == "guardar" and es_borrador:
            messages.success(request, "Cambios guardados.")
        elif accion in ("mas", "menos", "quitar") and es_borrador:
            item = cotizacion.items.filter(pk=valor or 0).first()
            if item and accion == "quitar":
                item.delete()
            elif item:
                item.cantidad = max(1, item.cantidad + (1 if accion == "mas" else -1))
                item.save(update_fields=["cantidad"])
        elif accion == "agregar_servicio" and es_borrador:
            servicio = Servicio.objects.filter(pk=valor or 0, activo=True).first()
            if servicio:
                _agregar_servicio(cotizacion, servicio)
        elif accion == "agregar_plan" and es_borrador:
            plan = Plan.objects.filter(pk=valor or 0, activo=True).first()
            if plan:
                _agregar_plan(cotizacion, plan)
        elif accion in ("ia_regenerar", "ia_acortar", "ia_formal") and es_borrador:
            _accion_ia_cotizacion(request, cotizacion, accion)
        elif accion == "enviar" and es_borrador:
            if not puede_aprobar(request.user):
                messages.error(request, "Solo la administradora puede aprobar y enviar una cotización.")
            elif not cotizacion.items.exists():
                messages.error(request, "Agrega al menos un servicio antes de marcarla como enviada.")
            else:
                cotizacion.estado = Cotizacion.Estado.ENVIADA
                cotizacion.enviada_en = timezone.now()
                cotizacion.save(update_fields=["estado", "enviada_en", "actualizado_en"])
                
                # Avanza la etapa del prospecto
                if prospecto.etapa in (Prospecto.Etapa.NUEVO, Prospecto.Etapa.DIAGNOSTICO):
                    _mover_etapa(prospecto, Prospecto.Etapa.COTIZACION_ENVIADA, request.user)
                
                # Intento de envío de correo HTML + Texto plano
                correo_enviado = False
                try:
                    from django.core.mail import EmailMultiAlternatives
                    from django.template.loader import render_to_string
                    from django.utils.html import strip_tags

                    asunto = f"Cotización #{cotizacion.numero} · Agencia Cosmopolitan"
                    remitente = getattr(settings, "DEFAULT_FROM_EMAIL", "contacto@agenciacosmopolitan.cl")
                    
                    contexto_email = {
                        "cotizacion": cotizacion,
                        "prospecto": prospecto,
                        "totales": cotizacion.totales(),
                    }
                    
                    html_content = render_to_string("crm/email_cotizacion.html", contexto_email)
                    text_content = strip_tags(html_content)

                    msg = EmailMultiAlternatives(
                        subject=asunto,
                        body=text_content,
                        from_email=remitente,
                        to=[prospecto.correo],
                    )
                    msg.attach_alternative(html_content, "text/html")
                    msg.send(fail_silently=False)
                    correo_enviado = True

                except Exception as e:
                    messages.warning(request, f"La cotización cambió a 'Enviada', pero no se pudo enviar el correo automático: {e}")

                _registrar(
                    prospecto, 
                    request.user, 
                    f"Cotización #{cotizacion.numero} enviada" + (" por correo" if correo_enviado else ""), 
                    Interaccion.Tipo.CORREO
                )
                
                if correo_enviado:
                    messages.success(request, f"Cotización #{cotizacion.numero} aprobada y enviada exitosamente por correo a {prospecto.correo}.")
                else:
                    messages.success(request, f"Cotización #{cotizacion.numero} aprobada y marcada como enviada.")
        elif accion in ("aceptada", "rechazada") and cotizacion.estado == Cotizacion.Estado.ENVIADA:
            cotizacion.estado = accion
            cotizacion.respondida_en = timezone.now()
            cotizacion.save(update_fields=["estado", "respondida_en", "actualizado_en"])
            _registrar(prospecto, request.user, f"Cotización #{cotizacion.numero} {cotizacion.get_estado_display().lower()}")
            if accion == "aceptada":
                _mover_etapa(prospecto, Prospecto.Etapa.GANADO, request.user)
            messages.success(request, f"Cotización marcada como {cotizacion.get_estado_display().lower()}.")
        elif accion == "volver_borrador" and cotizacion.estado == Cotizacion.Estado.ENVIADA:
            cotizacion.estado = Cotizacion.Estado.BORRADOR
            cotizacion.enviada_en = None
            cotizacion.save(update_fields=["estado", "enviada_en", "actualizado_en"])
            messages.info(request, "La cotización volvió a borrador para editarla.")
        return redirect("crm:cotizacion_editar", pk=cotizacion.pk)

    items = list(cotizacion.items.select_related("plan", "servicio"))
    en_items_servicios = {i.servicio_id for i in items if i.servicio_id}
    en_items_planes = {i.plan_id for i in items if i.plan_id}
    totales = cotizacion.totales()
    checklist = [
        {"texto": "Prospecto con correo de contacto", "hecho": bool(prospecto.correo)},
        {"texto": "Al menos un servicio o plan", "hecho": bool(items)},
        {"texto": "Diagnóstico escrito", "hecho": bool(cotizacion.diagnostico.strip())},
        {"texto": "Diagnóstico IA revisado por el equipo", "hecho": bool(prospecto.diagnostico_revisado_en)},
        {"texto": "Validez y fecha de inicio definidas", "hecho": bool(cotizacion.valida_hasta and cotizacion.inicio_estimado)},
    ]
    context = contexto_panel(
        request,
        "cotizaciones",
        cotizacion=cotizacion,
        prospecto=prospecto,
        items=items,
        totales=totales,
        editable=cotizacion.estado == Cotizacion.Estado.BORRADOR,
        puede_aprobar=puede_aprobar(request.user),
        planes_disponibles=Plan.objects.filter(activo=True).exclude(pk__in=en_items_planes),
        servicios_disponibles=Servicio.objects.filter(activo=True).exclude(pk__in=en_items_servicios),
        formas_pago=Cotizacion.FormaPago.choices,
        descuentos=[(0, "Sin descuento"), (5, "5%"), (10, "10%"), (15, "15%")],
        checklist=checklist,
        ia_configurada=bool(settings.AI_API_KEY),
        maximo_diagnostico=4000,
    )
    return render(request, "crm/cotizacion_editar.html", context)


def _accion_ia_cotizacion(request, cotizacion, accion):
    try:
        if accion == "ia_regenerar":
            cotizacion.diagnostico = generar_diagnostico_cotizacion(cotizacion.prospecto, request.user)
            mensaje = "Diagnóstico regenerado con IA. Revísalo antes de enviar."
        else:
            instruccion = "Acórtalo a la mitad manteniendo lo esencial." if accion == "ia_acortar" else "Reescríbelo con un tono más formal, tratando de usted."
            cotizacion.diagnostico = reescribir_texto(cotizacion.diagnostico, instruccion, request.user, cotizacion.prospecto)
            mensaje = "Diagnóstico reescrito con IA. Revísalo antes de enviar."
        cotizacion.save(update_fields=["diagnostico", "actualizado_en"])
        messages.success(request, mensaje)
    except IANoConfigurada:
        messages.error(request, "La IA no está configurada: falta AI_API_KEY en el archivo .env.")
    except ErrorIA as e:
        messages.error(request, f"No se pudo usar la IA. {e}")


@solo_equipo
def cotizacion_imprimir(request, pk):
    cotizacion = get_object_or_404(Cotizacion.objects.select_related("prospecto"), pk=pk)
    return render(request, "crm/cotizacion_imprimir.html", {
        "cotizacion": cotizacion,
        "items": cotizacion.items.all(),
        "totales": cotizacion.totales(),
    })


# ── Clientes ──────────────────────────────────────────────────────────────────

@solo_equipo
def clientes(request):
    lista = clientes_visibles(request.user).select_related("prospecto", "plan").order_by("-creado_en")
    return render(request, "crm/clientes.html", contexto_panel(request, "clientes", clientes=lista))


def _documentos_del_cliente(cliente):
    # all_objects: el filtro por tenant lo aplica ya obtener_cliente_visible sobre el cliente.
    return DocumentoCliente.all_objects.filter(cliente=cliente).select_related("subido_por")


@solo_equipo
def cliente_ficha(request, pk):
    """Ficha única del cliente: contrato, marca, objetivos, KPIs y documentos (PC-CLI-02)."""
    cliente = obtener_cliente_visible(request.user, pk)
    puede_editar = puede_aprobar(request.user)
    form = ClienteFichaForm(instance=cliente)
    if request.method == "POST":
        if not puede_editar:
            messages.error(request, "Solo la administradora puede editar la ficha del cliente.")
            return redirect("crm:cliente_ficha", pk=cliente.pk)
        form = ClienteFichaForm(request.POST, instance=cliente)
        if form.is_valid():
            form.save()
            RegistroAuditoria.registrar(
                usuario=request.user, accion=RegistroAuditoria.Accion.EDITAR, entidad="cliente",
                entidad_id=cliente.pk, detalle=f"Ficha de {cliente.nombre}",
            )
            messages.success(request, "Ficha del cliente actualizada.")
            return redirect("crm:cliente_ficha", pk=cliente.pk)
    return render(request, "crm/cliente_ficha.html", contexto_panel(
        request, "clientes",
        cliente=cliente, form=form, puede_editar=puede_editar,
        documentos=_documentos_del_cliente(cliente), doc_form=DocumentoClienteForm(),
        kpis=_kpis_del_cliente(cliente), kpi_form=KPIForm(cliente=cliente), medicion_form=MedicionForm(initial={"fecha": timezone.localdate()}),
        **_contexto_acceso_portal(request, cliente),
    ))


# ── Acceso al portal del cliente (PC-AUT-07) ──────────────────────────────────

def _puede_invitar(user):
    # Misma regla que requiere_administradora: «Usuarios y roles» es solo de la administradora (Alcance 9.3).
    return user.rol == Rol.ADMINISTRADORA or user.is_superuser


def _contexto_acceso_portal(request, cliente, invitacion_form=None):
    if not _puede_invitar(request.user):
        return {"puede_invitar": False}
    cuentas = []
    for u in cliente.usuarios.order_by("first_name", "email"):
        estado = activacion.estado_cuenta(u)
        cuentas.append({
            "usuario": u,
            "estado": estado,
            "etiqueta": activacion.ETIQUETAS_ESTADO[estado],
            "enlace": activacion.enlace_activacion(request, u) if estado == activacion.Estado.PENDIENTE else "",
        })
    if invitacion_form is None:
        # Se propone el contacto principal solo si todavía no tiene cuenta (si no, el formulario lo rechazaría).
        inicial = {}
        if cliente.contacto_correo and not get_user_model().objects.filter(email__iexact=cliente.contacto_correo).exists():
            nombre, _, apellido = (cliente.contacto_nombre or "").strip().partition(" ")
            inicial = {"first_name": nombre, "last_name": apellido, "email": cliente.contacto_correo}
        invitacion_form = InvitacionClienteForm(initial=inicial)
    return {
        "puede_invitar": True,
        "cuentas_portal": cuentas,
        "invitacion_form": invitacion_form,
        "dias_activacion": activacion.dias_vigencia(),
    }


@requiere_administradora
@require_POST
def cliente_invitar(request, pk):
    cliente = obtener_cliente_visible(request.user, pk)
    if not cliente.activo:
        messages.error(request, "El cliente está inactivo: actívalo en la ficha antes de darle acceso al portal.")
        return redirect("crm:cliente_ficha", pk=cliente.pk)
    form = InvitacionClienteForm(request.POST)
    if not form.is_valid():
        _errores_como_mensajes(request, form)
        return redirect(f"{reverse('crm:cliente_ficha', args=[cliente.pk])}#acceso-portal")

    datos = form.cleaned_data
    usuario = get_user_model()(
        username=activacion.username_unico(datos["email"]),
        email=datos["email"],
        first_name=datos["first_name"],
        last_name=datos["last_name"],
        rol=datos["rol"],
        cliente=cliente,
        is_staff=False,
        is_active=True,
    )
    usuario.set_unusable_password()
    usuario.save()
    RegistroAuditoria.registrar(
        usuario=request.user, accion=RegistroAuditoria.Accion.CREAR, entidad="usuario", entidad_id=usuario.pk,
        detalle=f"{usuario.username} · {usuario.get_rol_display()} · invitación al portal de {cliente.nombre}",
    )
    if activacion.enviar_invitacion(request, usuario):
        messages.success(request, f"Cuenta creada. Enviamos la invitación a {usuario.email}; queda pendiente hasta que la active.")
    else:
        messages.warning(
            request,
            f"Cuenta creada, pero no se pudo enviar el correo a {usuario.email} (el envío de correos aún no está "
            "configurado). Copia el enlace de activación desde «Acceso al portal» y envíaselo por otro medio.",
        )
    return redirect(f"{reverse('crm:cliente_ficha', args=[cliente.pk])}#acceso-portal")


@requiere_administradora
@require_POST
def cliente_reenviar_invitacion(request, pk, usuario_pk):
    cliente = obtener_cliente_visible(request.user, pk)
    usuario = get_object_or_404(get_user_model(), pk=usuario_pk, cliente=cliente)
    destino = f"{reverse('crm:cliente_ficha', args=[cliente.pk])}#acceso-portal"
    if activacion.estado_cuenta(usuario) != activacion.Estado.PENDIENTE:
        messages.info(request, f"La cuenta de {usuario.email} ya no está pendiente de activación.")
        return redirect(destino)
    RegistroAuditoria.registrar(
        usuario=request.user, accion=RegistroAuditoria.Accion.EDITAR, entidad="usuario", entidad_id=usuario.pk,
        detalle=f"{usuario.username} · invitación al portal reenviada",
    )
    if activacion.enviar_invitacion(request, usuario):
        messages.success(request, f"Invitación reenviada a {usuario.email}.")
    else:
        messages.warning(request, f"No se pudo enviar el correo a {usuario.email}. Copia el enlace de activación y envíaselo por otro medio.")
    return redirect(destino)


@solo_equipo
@require_POST
def cliente_documento_subir(request, pk):
    cliente = obtener_cliente_visible(request.user, pk)
    if not puede_aprobar(request.user):
        messages.error(request, "Solo la administradora puede subir documentos a la ficha.")
        return redirect("crm:cliente_ficha", pk=cliente.pk)
    form = DocumentoClienteForm(request.POST, request.FILES)
    if form.is_valid():
        documento = form.save(commit=False)
        documento.cliente = cliente
        documento.subido_por = request.user
        documento.save()
        messages.success(request, f"Documento «{documento.nombre}» subido.")
    else:
        for errores in form.errors.values():
            for error in errores:
                messages.error(request, error)
    return redirect("crm:cliente_ficha", pk=cliente.pk)


def _kpis_del_cliente(cliente):
    return KPICliente.all_objects.filter(cliente=cliente)


def _errores_como_mensajes(request, form):
    for errores in form.errors.values():
        for error in errores:
            messages.error(request, error)


@solo_equipo
@require_POST
def cliente_kpi_crear(request, pk):
    cliente = obtener_cliente_visible(request.user, pk)
    if not puede_aprobar(request.user):
        messages.error(request, "Solo la administradora puede agregar KPIs a la ficha.")
        return redirect("crm:cliente_ficha", pk=cliente.pk)
    form = KPIForm(request.POST, cliente=cliente)
    if form.is_valid():
        kpi = form.save(commit=False)
        kpi.cliente = cliente
        kpi.save()
        RegistroAuditoria.registrar(
            usuario=request.user, accion=RegistroAuditoria.Accion.CREAR, entidad="kpi",
            entidad_id=kpi.pk, detalle=f"{kpi.get_indicador_display()} de {cliente.nombre}",
        )
        messages.success(request, f"KPI «{kpi.get_indicador_display()}» agregado.")
    else:
        _errores_como_mensajes(request, form)
    return redirect("crm:cliente_ficha", pk=cliente.pk)


@solo_equipo
@require_POST
def cliente_kpi_medicion(request, pk, kpi_pk):
    cliente = obtener_cliente_visible(request.user, pk)
    if not puede_aprobar(request.user):
        messages.error(request, "Solo la administradora puede registrar mediciones.")
        return redirect("crm:cliente_ficha", pk=cliente.pk)
    kpi = get_object_or_404(_kpis_del_cliente(cliente), pk=kpi_pk)
    form = MedicionForm(request.POST)
    if form.is_valid():
        medicion = form.save(commit=False)
        medicion.kpi = kpi
        medicion.cliente = cliente
        medicion.fuente = MedicionKPI.Fuente.MANUAL
        medicion.registrado_por = request.user
        medicion.save()
        messages.success(request, f"Medición de «{kpi.get_indicador_display()}» registrada.")
    else:
        _errores_como_mensajes(request, form)
    return redirect("crm:cliente_ficha", pk=cliente.pk)


@solo_equipo
@require_POST
def cliente_kpi_eliminar(request, pk, kpi_pk):
    cliente = obtener_cliente_visible(request.user, pk)
    if not puede_aprobar(request.user):
        messages.error(request, "Solo la administradora puede quitar KPIs de la ficha.")
        return redirect("crm:cliente_ficha", pk=cliente.pk)
    kpi = get_object_or_404(_kpis_del_cliente(cliente), pk=kpi_pk)
    nombre = kpi.get_indicador_display()
    RegistroAuditoria.registrar(
        usuario=request.user, accion=RegistroAuditoria.Accion.ELIMINAR, entidad="kpi",
        entidad_id=kpi.pk, detalle=f"{nombre} de {cliente.nombre}",
    )
    kpi.delete()
    messages.success(request, f"KPI «{nombre}» eliminado junto con su historial.")
    return redirect("crm:cliente_ficha", pk=cliente.pk)


@solo_equipo
def cliente_documento_descargar(request, pk, doc_pk):
    cliente = obtener_cliente_visible(request.user, pk)
    documento = get_object_or_404(_documentos_del_cliente(cliente), pk=doc_pk)
    try:
        archivo = documento.archivo.open("rb")
    except (FileNotFoundError, ValueError):
        raise Http404("El archivo ya no está disponible.")
    return FileResponse(archivo, as_attachment=True, filename=documento.archivo.name.rsplit("/", 1)[-1])


@solo_equipo
@require_POST
def cliente_documento_eliminar(request, pk, doc_pk):
    cliente = obtener_cliente_visible(request.user, pk)
    if not puede_aprobar(request.user):
        messages.error(request, "Solo la administradora puede eliminar documentos de la ficha.")
        return redirect("crm:cliente_ficha", pk=cliente.pk)
    documento = get_object_or_404(_documentos_del_cliente(cliente), pk=doc_pk)
    nombre = documento.nombre
    documento.archivo.delete(save=False)
    documento.delete()
    messages.success(request, f"Documento «{nombre}» eliminado.")
    return redirect("crm:cliente_ficha", pk=cliente.pk)


@solo_equipo
@require_POST
def cliente_activo(request):
    """Selector de cliente activo del panel. Solo acepta clientes que el usuario puede ver."""
    elegido = request.POST.get("cliente", "").strip()
    if elegido:
        cliente = obtener_cliente_visible(request.user, elegido)
        request.session[SESSION_CLIENT_KEY] = cliente.pk
        messages.success(request, f"Cliente activo: {cliente.nombre}.")
    else:
        request.session.pop(SESSION_CLIENT_KEY, None)
        messages.success(request, "Ahora ves todos tus clientes.")
    return _volver(request, "crm:dashboard")

# ── Planes y servicios ─────────────────────────────────────────────────────────

@requiere_administradora
def planes_servicios(request):
    planes = Plan.objects.prefetch_related("entregables__tipo_entregable").order_by("orden", "precio_mensual")
    servicios = Servicio.objects.order_by("orden", "nombre")
    context = contexto_panel(request, "planes_servicios", planes=planes, servicios=servicios)
    return render(request, "crm/planes_servicios.html", context)

# ── Usuarios (CU-08, Alcance 4.3 / 9.3) ────────────────────────────────────────

@requiere_administradora
def usuarios(request):
    lista = get_user_model().objects.select_related("cliente").order_by("username")
    rol_activo = request.GET.get("rol", "")
    if rol_activo in Rol.values:
        lista = lista.filter(rol=rol_activo)

    busqueda = request.GET.get("q", "").strip()
    if busqueda:
        lista = lista.filter(
            Q(username__icontains=busqueda)
            | Q(first_name__icontains=busqueda)
            | Q(last_name__icontains=busqueda)
            | Q(email__icontains=busqueda)
        )

    con_2fa = set(
        Authenticator.objects.filter(user__in=lista, type=Authenticator.Type.TOTP).values_list("user_id", flat=True)
    )

    return render(
        request,
        "crm/usuarios.html",
        contexto_panel(
            request, "usuarios",
            usuarios=lista, roles=Rol.choices, rol_activo=rol_activo, busqueda=busqueda,
            con_2fa=con_2fa,
        ),
    )


@requiere_administradora
def usuario_nuevo(request):
    if request.method == "POST":
        form = UsuarioForm(request.POST, es_nuevo=True)
        if form.is_valid():
            usuario = form.save()
            RegistroAuditoria.registrar(
                usuario=request.user,
                accion=RegistroAuditoria.Accion.CREAR,
                entidad="usuario",
                entidad_id=usuario.pk,
                detalle=f"{usuario.username} · {usuario.get_rol_display() or 'sin rol'}",
            )
            messages.success(request, f"Usuario «{usuario.username}» creado.")
            return redirect("crm:usuarios")
    else:
        form = UsuarioForm(es_nuevo=True)
    return render(
        request,
        "crm/usuario_form.html",
        contexto_panel(request, "usuarios", form=form, es_nuevo=True),
    )


@requiere_administradora
def usuario_editar(request, pk):
    usuario_obj = get_object_or_404(get_user_model(), pk=pk)
    if request.method == "POST":
        form = UsuarioForm(request.POST, instance=usuario_obj)
        if form.is_valid():
            form.save()
            RegistroAuditoria.registrar(
                usuario=request.user,
                accion=RegistroAuditoria.Accion.EDITAR,
                entidad="usuario",
                entidad_id=usuario_obj.pk,
                detalle=f"{usuario_obj.username} · {usuario_obj.get_rol_display() or 'sin rol'}",
            )
            messages.success(request, f"Usuario «{usuario_obj.username}» actualizado.")
            return redirect("crm:usuarios")
    else:
        form = UsuarioForm(instance=usuario_obj)
    return render(
        request,
        "crm/usuario_form.html",
        contexto_panel(request, "usuarios", form=form, usuario_editado=usuario_obj),
    )


@requiere_administradora
@require_POST
def usuario_alternar_activo(request, pk):
    usuario_obj = get_object_or_404(get_user_model(), pk=pk)
    if usuario_obj.pk == request.user.pk:
        messages.error(request, "No puedes desactivar tu propia cuenta.")
        return _volver(request, "crm:usuarios")

    usuario_obj.is_active = not usuario_obj.is_active
    usuario_obj.save(update_fields=["is_active"])
    RegistroAuditoria.registrar(
        usuario=request.user,
        accion=RegistroAuditoria.Accion.EDITAR,
        entidad="usuario",
        entidad_id=usuario_obj.pk,
        detalle=f"{usuario_obj.username} · {'activado' if usuario_obj.is_active else 'desactivado'}",
    )
    messages.success(request, f"Usuario «{usuario_obj.username}» {'activado' if usuario_obj.is_active else 'desactivado'}.")
    return _volver(request, "crm:usuarios")


@requiere_administradora
@require_POST
def usuario_restablecer_2fa(request, pk):
    usuario_obj = get_object_or_404(get_user_model(), pk=pk)
    autenticadores = Authenticator.objects.filter(user=usuario_obj)
    if not autenticadores.exists():
        messages.info(request, f"«{usuario_obj.username}» no tiene 2FA activado.")
        return _volver(request, "crm:usuarios")

    autenticadores.delete()
    RegistroAuditoria.registrar(
        usuario=request.user,
        accion=RegistroAuditoria.Accion.EDITAR,
        entidad="usuario",
        entidad_id=usuario_obj.pk,
        detalle=f"{usuario_obj.username} · 2FA restablecido (admin)",
    )
    messages.success(
        request,
        f"2FA de «{usuario_obj.username}» restablecido. Podrá iniciar sesión sin código "
        "y configurar la app autenticadora nuevamente desde su panel de Seguridad.",
    )
    return _volver(request, "crm:usuarios")


@requiere_administradora
def usuario_eliminar(request, pk):
    usuario_obj = get_user_model().objects.filter(pk=pk).first()
    if usuario_obj is None:
        # Ya fue eliminado (doble clic, otra pestaña, etc.): no es un error, solo avisamos.
        messages.info(request, "Ese usuario ya había sido eliminado.")
        return redirect("crm:usuarios")

    if usuario_obj.pk == request.user.pk:
        messages.error(request, "No puedes eliminar tu propia cuenta.")
        return redirect("crm:usuarios")

    if request.method == "POST":
        nombre, rol_mostrado = usuario_obj.username, usuario_obj.get_rol_display() or "sin rol"
        usuario_obj.delete()
        RegistroAuditoria.registrar(
            usuario=request.user,
            accion=RegistroAuditoria.Accion.ELIMINAR,
            entidad="usuario",
            entidad_id=pk,
            detalle=f"{nombre} · {rol_mostrado}",
        )
        messages.success(request, f"Usuario «{nombre}» eliminado.")
        return redirect("crm:usuarios")

    return render(
        request,
        "crm/usuario_confirmar_eliminar.html",
        contexto_panel(request, "usuarios", usuario_a_eliminar=usuario_obj),
    )


# ── Registro de auditoría (solo lectura) ────────────────────────────────────

@requiere_administradora
def auditoria(request):
    registros = RegistroAuditoria.objects.select_related("usuario").order_by("-creado_en")

    accion_activa = request.GET.get("accion", "")
    if accion_activa in RegistroAuditoria.Accion.values:
        registros = registros.filter(accion=accion_activa)

    busqueda = request.GET.get("q", "").strip()
    if busqueda:
        registros = registros.filter(
            Q(detalle__icontains=busqueda)
            | Q(entidad__icontains=busqueda)
            | Q(usuario__username__icontains=busqueda)
        )

    # Se muestran los últimos 300 movimientos; es un registro de solo lectura, no necesita paginación por ahora.
    registros = registros[:300]

    return render(
        request,
        "crm/auditoria.html",
        contexto_panel(
            request, "auditoria",
            registros=registros, acciones=RegistroAuditoria.Accion.choices,
            accion_activa=accion_activa, busqueda=busqueda,
        ),
    )

def _slug_unico(modelo, nombre, pk_actual=None):
    base = slugify(nombre)[:50] or "item"
    slug = base
    n = 2
    qs = modelo.objects.exclude(pk=pk_actual) if pk_actual else modelo.objects.all()
    while qs.filter(slug=slug).exists():
        slug = f"{base}-{n}"
        n += 1
    return slug


@requiere_administradora
def servicio_form(request, pk=None):
    servicio = get_object_or_404(Servicio, pk=pk) if pk else None
    if request.method == "POST":
        form = ServicioForm(request.POST, instance=servicio)
        if form.is_valid():
            obj = form.save(commit=False)
            if not obj.slug:
                obj.slug = _slug_unico(Servicio, obj.nombre, obj.pk)
            obj.save()
            messages.success(request, "Servicio guardado.")
            return redirect("crm:planes_servicios")
    else:
        form = ServicioForm(instance=servicio)
    context = contexto_panel(request, "planes_servicios", form=form, servicio=servicio)
    return render(request, "crm/servicio_formulario.html", context)


@requiere_administradora
def plan_form(request, pk=None):
    plan = get_object_or_404(Plan, pk=pk) if pk else None
    if request.method == "POST":
        form = PlanForm(request.POST, instance=plan)
        formset = PlanEntregableFormSet(request.POST, instance=plan if plan else Plan(), prefix="entregables")
        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                obj = form.save(commit=False)
                if not obj.slug:
                    obj.slug = _slug_unico(Plan, obj.nombre, obj.pk)
                obj.save()
                formset.instance = obj
                formset.save()
            messages.success(request, "Plan guardado.")
            return redirect("crm:planes_servicios")
    else:
        form = PlanForm(instance=plan)
        formset = PlanEntregableFormSet(instance=plan, prefix="entregables")
    context = contexto_panel(request, "planes_servicios", form=form, formset=formset, plan=plan)
    return render(request, "crm/plan_formulario.html", context)

@requiere_administradora
@require_POST
def plan_alternar_activo(request, pk):
    plan = get_object_or_404(Plan, pk=pk)
    plan.activo = not plan.activo
    plan.save(update_fields=["activo"])
    messages.success(request, f"Plan {'activado' if plan.activo else 'desactivado'}.")
    return redirect("crm:planes_servicios")

@requiere_administradora
@require_POST
def servicio_alternar_activo(request, pk):
    servicio = get_object_or_404(Servicio, pk=pk)
    servicio.activo = not servicio.activo
    servicio.save(update_fields=["activo"])
    messages.success(request, f"Servicio {'activado' if servicio.activo else 'desactivado'}.")
    return redirect("crm:planes_servicios")


# ── Contenido del sitio / CMS (PC-WEB-02) ───────────────────────────────────

@requiere_administradora
def contenidos(request):
    lista = Contenido.objects.all()
    seccion_activa = request.GET.get("seccion", "")
    if seccion_activa in Contenido.Seccion.values:
        lista = lista.filter(seccion=seccion_activa)
    estado_activo = request.GET.get("estado", "")
    if estado_activo in Contenido.Estado.values:
        lista = lista.filter(estado=estado_activo)
    context = contexto_panel(
        request, "contenidos",
        contenidos=lista, secciones=Contenido.Seccion.choices, estados=Contenido.Estado.choices,
        seccion_activa=seccion_activa, estado_activo=estado_activo,
    )
    return render(request, "crm/contenidos.html", context)


@requiere_administradora
def contenido_form(request, pk=None):
    contenido = get_object_or_404(Contenido, pk=pk) if pk else None
    if request.method == "POST":
        form = ContenidoForm(request.POST, request.FILES, instance=contenido)
        if form.is_valid():
            es_nuevo = contenido is None
            obj = form.save(commit=False)
            if es_nuevo:
                obj.creado_por = request.user
            obj.save()
            RegistroAuditoria.registrar(
                usuario=request.user,
                accion=RegistroAuditoria.Accion.CREAR if es_nuevo else RegistroAuditoria.Accion.EDITAR,
                entidad="contenido del sitio",
                entidad_id=obj.pk,
                detalle=f"{obj.titulo} · {obj.get_estado_display()}",
            )
            messages.success(request, f"Contenido «{obj.titulo}» guardado como {obj.get_estado_display().lower()}.")
            return redirect("crm:contenidos")
    else:
        form = ContenidoForm(instance=contenido)
    context = contexto_panel(request, "contenidos", form=form, contenido=contenido)
    return render(request, "crm/contenido_formulario.html", context)


@requiere_administradora
@require_POST
def contenido_alternar_publicado(request, pk):
    contenido = get_object_or_404(Contenido, pk=pk)
    if contenido.estado == Contenido.Estado.PUBLICADO:
        contenido.estado = Contenido.Estado.BORRADOR
    else:
        contenido.estado = Contenido.Estado.PUBLICADO
    contenido.save()
    RegistroAuditoria.registrar(
        usuario=request.user,
        accion=RegistroAuditoria.Accion.EDITAR,
        entidad="contenido del sitio",
        entidad_id=contenido.pk,
        detalle=f"{contenido.titulo} · {contenido.get_estado_display()}",
    )
    messages.success(request, f"«{contenido.titulo}» ahora está {contenido.get_estado_display().lower()}.")
    return _volver(request, "crm:contenidos")


@requiere_administradora
def seo_paginas(request):
    """Metadatos SEO (título y descripción) de las páginas fijas del sitio (PC-SEO-01b, CP-009).

    Un formulario por página en la misma pantalla; solo se guardan, y quedan en la auditoría,
    las páginas que cambiaron.
    """
    existentes = {m.pagina: m for m in MetadatosPagina.objects.all()}
    filas = []
    for valor, etiqueta in MetadatosPagina.Pagina.choices:
        instancia = existentes.get(valor) or MetadatosPagina(pagina=valor)
        form = MetadatosPaginaForm(request.POST or None, instance=instancia, prefix=valor)
        filas.append({"valor": valor, "etiqueta": etiqueta, "url": reverse_lazy(f"website:{valor}"), "form": form})

    if request.method == "POST":
        if all(f["form"].is_valid() for f in filas):
            cambiadas = []
            with transaction.atomic():
                for fila in filas:
                    if not fila["form"].has_changed():
                        continue
                    obj = fila["form"].save(commit=False)
                    obj.actualizado_por = request.user
                    obj.save()
                    RegistroAuditoria.registrar(
                        usuario=request.user,
                        accion=RegistroAuditoria.Accion.EDITAR,
                        entidad="SEO de página",
                        entidad_id=obj.pagina,
                        detalle=f"{fila['etiqueta']} · título: {obj.meta_titulo or '(por defecto)'}"[:255],
                    )
                    cambiadas.append(fila["etiqueta"])
            if cambiadas:
                messages.success(request, f"Metadatos guardados: {', '.join(cambiadas)}.")
            else:
                messages.info(request, "No había cambios que guardar.")
            return redirect("crm:seo_paginas")
        messages.error(request, "Revisa los campos marcados.")

    return render(request, "crm/seo_paginas.html", contexto_panel(request, "contenidos", filas=filas))


@requiere_administradora
def configuracion(request):
    """Datos de contacto de la agencia que usa el sitio, la cotización y los avisos por correo.

    Reemplaza el enlace al admin de Django. Queda en la auditoría qué campos cambiaron.
    """
    config = ConfiguracionAgencia.actual()
    form = ConfiguracionAgenciaForm(request.POST or None, instance=config)
    if request.method == "POST":
        if form.is_valid():
            if form.has_changed():
                obj = form.save(commit=False)
                obj.actualizado_por = request.user
                obj.save()
                etiquetas = ", ".join(str(form.fields[c].label) for c in form.changed_data)
                RegistroAuditoria.registrar(
                    usuario=request.user,
                    accion=RegistroAuditoria.Accion.EDITAR,
                    entidad="configuración de la agencia",
                    entidad_id=obj.pk,
                    detalle=f"Campos: {etiquetas}"[:255],
                )
                messages.success(request, "Configuración guardada. El sitio ya muestra los datos nuevos.")
            else:
                messages.info(request, "No había cambios que guardar.")
            return redirect("crm:configuracion")
        messages.error(request, "Revisa los campos marcados.")
    contexto = contexto_panel(
        request, "configuracion", form=form, config=config,
        campos_contacto=[form[c] for c in ("correo", "telefono", "whatsapp", "ciudad")],
        campos_redes=[form[c] for c in ("instagram_usuario", "linkedin_nombre", "linkedin_url")],
    )
    return render(request, "crm/configuracion.html", contexto)
