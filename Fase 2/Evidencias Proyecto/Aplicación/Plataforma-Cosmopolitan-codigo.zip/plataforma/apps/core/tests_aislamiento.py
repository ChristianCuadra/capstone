"""PC-TEC-04 · Suite de pruebas de aislamiento entre clientes y de permisos por rol.

Cubre CP-019 (usuario cliente sin acceso al panel, con el intento registrado en la bitácora),
CP-020 (acceso por URL a un recurso de otro cliente) y CP-021 (manipulación del identificador
de cliente). Criterio de la suite: todo intento de leer datos de otro cliente o de ejecutar una acción
fuera del rol debe quedar denegado, sin revelar la existencia del recurso.

Se ejecuta con el resto de los tests en la integración continua (`python manage.py test apps`).
"""

from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied
from django.core.files.base import ContentFile
from django.test import TestCase
from django.urls import reverse

from apps.clients.models import Cliente, DocumentoCliente
from apps.core.context import get_allowed_client_ids, reset_allowed_client_ids, set_allowed_client_ids
from apps.core.middleware import SESSION_CLIENT_KEY
from apps.core.models import RegistroAuditoria

User = get_user_model()

# Vistas del panel que cualquier usuario del equipo puede abrir, y las exclusivas de la administradora.
PANEL_EQUIPO = [
    ("crm:dashboard", []), ("crm:prospectos", []), ("crm:prospecto_nuevo", []),
    ("crm:cotizaciones", []), ("crm:clientes", []), ("crm:contenidos", []),
    ("crm:prospecto_detalle", [1]), ("crm:cotizacion_editar", [1]), ("crm:cliente_ficha", [1]),
    ("crm:cliente_documento_descargar", [1, 1]),
]
PANEL_SOLO_ADMIN = [
    # Descarga masiva de datos personales: solo administración (Ley 21.719).
    ("crm:prospectos_exportar", []), ("crm:prospecto_datos_personales", [1]),
    ("crm:usuarios", []), ("crm:usuario_nuevo", []), ("crm:usuario_editar", [1]), ("crm:auditoria", []),
    ("crm:usuario_alternar_activo", [1]), ("crm:usuario_restablecer_2fa", [1]), ("crm:usuario_eliminar", [1]),
    ("crm:planes_servicios", []), ("crm:plan_nuevo", []), ("crm:plan_editar", [1]),
    ("crm:servicio_nuevo", []), ("crm:servicio_editar", [1]), ("crm:seo_paginas", []), ("crm:configuracion", []),
]
ACCIONES_POST = [
    ("crm:cliente_activo", []), ("crm:cliente_documento_subir", [1]), ("crm:cliente_documento_eliminar", [1, 1]),
    ("crm:prospecto_mover", [1]), ("crm:tarea_crear", []),
]


def _destino(respuesta):
    """Ruta a la que redirige una respuesta, sin el parámetro ?next=."""
    return respuesta["Location"].split("?")[0]


PORTAL = ["content:calendario", "content:aprobacion", "content:metricas"]


class BaseAislamiento(TestCase):
    def setUp(self):
        self._tokens = []
        self.addCleanup(self._restaurar_contexto)
        self.a = Cliente.objects.create(nombre="Panadería Alfa")
        self.b = Cliente.objects.create(nombre="Clínica Beta Secreta")
        self.admin = User.objects.create_user("adm", "adm@x.cl", "x", rol="administradora", is_staff=True)
        self.colab = User.objects.create_user("col", "col@x.cl", "x", rol="colaboradora", is_staff=True)
        self.colab.clientes_asignados.set([self.a])
        self.aprobador_a = User.objects.create_user("apa", "apa@x.cl", "x", rol="cliente_aprobador", cliente=self.a)
        self.lector_a = User.objects.create_user("lea", "lea@x.cl", "x", rol="cliente_lector", cliente=self.a)
        self.doc_b = DocumentoCliente.all_objects.create(
            cliente=self.b, nombre="Contrato Beta", archivo=ContentFile(b"confidencial-b", name="beta.pdf")
        )
        self.doc_a = DocumentoCliente.all_objects.create(
            cliente=self.a, nombre="Contrato Alfa", archivo=ContentFile(b"datos-a", name="alfa.pdf")
        )

    def _restringir(self, ids):
        self._tokens.append(set_allowed_client_ids(ids))

    def _restaurar_contexto(self):
        while self._tokens:
            reset_allowed_client_ids(self._tokens.pop())


class PermisosPorRolTests(BaseAislamiento):
    """Acciones fuera de rol: todas denegadas y sin efectos."""

    def test_anonimo_no_entra_al_panel_ni_al_portal(self):
        for nombre, args in PANEL_EQUIPO + PANEL_SOLO_ADMIN:
            with self.subTest(vista=nombre):
                r = self.client.get(reverse(nombre, args=args))
                self.assertEqual(r.status_code, 302)
                self.assertIn("login", r["Location"])
        for nombre in PORTAL:
            with self.subTest(vista=nombre):
                self.assertEqual(self.client.get(reverse(nombre)).status_code, 302)

    def test_usuarios_cliente_no_entran_a_ninguna_vista_del_panel(self):
        for usuario in (self.aprobador_a, self.lector_a):
            self.client.force_login(usuario)
            for nombre, args in PANEL_EQUIPO + PANEL_SOLO_ADMIN:
                with self.subTest(usuario=usuario.username, vista=nombre):
                    r = self.client.get(reverse(nombre, args=args))
                    self.assertEqual(r.status_code, 302)
                    self.assertFalse(_destino(r).startswith("/panel/"))

    def test_usuarios_cliente_no_ejecutan_acciones_del_panel(self):
        usuarios_antes = User.objects.count()
        docs_antes = DocumentoCliente.all_objects.count()
        for usuario in (self.aprobador_a, self.lector_a):
            self.client.force_login(usuario)
            for nombre, args in ACCIONES_POST + [("crm:usuario_eliminar", [self.admin.pk]), ("crm:usuario_alternar_activo", [self.admin.pk])]:
                with self.subTest(usuario=usuario.username, accion=nombre):
                    r = self.client.post(reverse(nombre, args=args), {"cliente": self.b.pk})
                    self.assertIn(r.status_code, (302, 403, 404, 405))
                    if r.status_code == 302:
                        self.assertFalse(_destino(r).startswith("/panel/"))
        self.assertEqual(User.objects.count(), usuarios_antes)
        self.assertEqual(DocumentoCliente.all_objects.count(), docs_antes)
        self.assertTrue(User.objects.get(pk=self.admin.pk).is_active)

    def test_colaboradora_no_entra_a_vistas_de_administradora(self):
        self.client.force_login(self.colab)
        for nombre, args in PANEL_SOLO_ADMIN:
            with self.subTest(vista=nombre):
                r = self.client.get(reverse(nombre, args=args))
                self.assertEqual(r.status_code, 302)

    def test_colaboradora_no_modifica_el_catalogo_por_post(self):
        """PC-CAT-01: solo la administradora crea, edita o desactiva planes y servicios."""
        from apps.catalog.models import Plan, Servicio

        plan = Plan.objects.create(nombre="Plan Prueba", slug="plan-prueba", precio_mensual=100000, activo=True)
        servicio = Servicio.objects.filter(activo=True).first()
        self.client.force_login(self.colab)
        r = self.client.post(reverse("crm:plan_alternar_activo", args=[plan.pk]))
        self.assertFalse(_destino(r).startswith("/panel/planes-servicios"))
        plan.refresh_from_db()
        self.assertTrue(plan.activo)
        if servicio:
            self.client.post(reverse("crm:servicio_alternar_activo", args=[servicio.pk]))
            servicio.refresh_from_db()
            self.assertTrue(servicio.activo)
        self.client.post(reverse("crm:plan_editar", args=[plan.pk]), {"nombre": "Hackeado", "precio_mensual": 1})
        plan.refresh_from_db()
        self.assertEqual(plan.precio_mensual, 100000)

    def test_colaboradora_no_ve_planes_y_servicios_en_el_menu(self):
        self.client.force_login(self.colab)
        r = self.client.get(reverse("crm:dashboard"))
        self.assertNotContains(r, reverse("crm:planes_servicios"))

    def test_colaboradora_no_gestiona_usuarios_por_post(self):
        self.client.force_login(self.colab)
        antes = User.objects.count()
        self.client.post(reverse("crm:usuario_eliminar", args=[self.lector_a.pk]))
        self.client.post(reverse("crm:usuario_alternar_activo", args=[self.lector_a.pk]))
        self.assertEqual(User.objects.count(), antes)
        self.assertTrue(User.objects.get(pk=self.lector_a.pk).is_active)

    def test_usuario_equipo_no_entra_al_portal_del_cliente(self):
        for usuario in (self.colab, self.admin):
            self.client.force_login(usuario)
            for nombre in PORTAL:
                with self.subTest(usuario=usuario.username, vista=nombre):
                    r = self.client.get(reverse(nombre))
                    self.assertEqual(r.status_code, 302)
                    self.assertFalse(_destino(r).startswith("/portal/"))

    def test_cliente_con_casilla_de_equipo_marcada_igual_no_entra_al_panel(self):
        """El rol manda: is_staff mal marcado en un cliente no le abre prospectos ni cotizaciones de todos."""
        self.aprobador_a.is_staff = True
        self.aprobador_a.save()
        self.client.force_login(self.aprobador_a)
        for nombre, args in PANEL_EQUIPO:
            with self.subTest(vista=nombre):
                r = self.client.get(reverse(nombre, args=args))
                self.assertEqual(r.status_code, 302)
                self.assertFalse(_destino(r).startswith("/panel/"))

    def test_formulario_de_usuarios_no_permite_cliente_con_acceso_al_panel(self):
        from apps.accounts.forms import UsuarioForm

        form = UsuarioForm({
            "username": "nuevo", "email": "nuevo@x.cl", "first_name": "N", "last_name": "U",
            "rol": "cliente_lector", "cliente": self.a.pk, "is_staff": "on", "is_active": "on", "password": "Clave-123-x",
        }, es_nuevo=True)
        self.assertFalse(form.is_valid())
        self.assertIn("is_staff", form.errors)

    def test_colaboradora_sin_casilla_de_equipo_entra_al_panel_por_su_rol(self):
        self.colab.is_staff = False
        self.colab.save()
        self.client.force_login(self.colab)
        self.assertEqual(self.client.get(reverse("crm:dashboard")).status_code, 200)


class AccesoPorUrlEntreClientesTests(BaseAislamiento):
    """CP-020: pedir por URL un recurso de otro cliente se deniega sin revelar que existe."""

    def _sin_fuga(self, respuesta):
        self.assertNotEqual(respuesta.status_code, 200)
        contenido = getattr(respuesta, "content", b"").decode("utf-8", "ignore")
        for secreto in ("Clínica Beta Secreta", "Contrato Beta", "confidencial-b"):
            self.assertNotIn(secreto, contenido)

    def test_ficha_de_cliente_ajeno_da_404(self):
        self.client.force_login(self.colab)
        r = self.client.get(reverse("crm:cliente_ficha", args=[self.b.pk]))
        self.assertEqual(r.status_code, 404)
        self._sin_fuga(r)

    def test_cliente_inexistente_y_cliente_ajeno_responden_igual(self):
        """No se revela la existencia: 'no existe' y 'no es tuyo' son indistinguibles."""
        self.client.force_login(self.colab)
        ajeno = self.client.get(reverse("crm:cliente_ficha", args=[self.b.pk]))
        inexistente = self.client.get(reverse("crm:cliente_ficha", args=[999999]))
        self.assertEqual(ajeno.status_code, inexistente.status_code)

    def test_documento_ajeno_no_se_descarga_con_ningun_cliente_en_la_url(self):
        self.client.force_login(self.colab)
        for cliente_en_url in (self.a.pk, self.b.pk):
            with self.subTest(cliente_en_url=cliente_en_url):
                r = self.client.get(reverse("crm:cliente_documento_descargar", args=[cliente_en_url, self.doc_b.pk]))
                self._sin_fuga(r)

    def test_documento_ajeno_no_se_elimina(self):
        self.client.force_login(self.colab)
        self.client.post(reverse("crm:cliente_documento_eliminar", args=[self.b.pk, self.doc_b.pk]))
        self.client.post(reverse("crm:cliente_documento_eliminar", args=[self.a.pk, self.doc_b.pk]))
        self.assertTrue(DocumentoCliente.all_objects.filter(pk=self.doc_b.pk).exists())

    def test_no_se_sube_documento_a_cliente_ajeno(self):
        from django.core.files.uploadedfile import SimpleUploadedFile

        self.client.force_login(self.colab)
        r = self.client.post(
            reverse("crm:cliente_documento_subir", args=[self.b.pk]),
            {"nombre": "Intruso", "tipo": "otro", "archivo": SimpleUploadedFile("x.pdf", b"x")},
        )
        self.assertEqual(r.status_code, 404)
        self.assertFalse(DocumentoCliente.all_objects.filter(nombre="Intruso").exists())

    def test_no_se_edita_ficha_de_cliente_ajeno(self):
        self.client.force_login(self.colab)
        self.client.post(reverse("crm:cliente_ficha", args=[self.b.pk]), {"nombre": "Hackeada", "objetivos": "x"})
        self.b.refresh_from_db()
        self.assertEqual(self.b.nombre, "Clínica Beta Secreta")

    def test_ficha_propia_no_contiene_datos_del_otro_cliente(self):
        self.client.force_login(self.colab)
        r = self.client.get(reverse("crm:cliente_ficha", args=[self.a.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Contrato Alfa")
        self.assertNotContains(r, "Clínica Beta Secreta")
        self.assertNotContains(r, "Contrato Beta")

    def test_listado_y_selector_de_la_colaboradora_no_nombran_al_otro_cliente(self):
        self.client.force_login(self.colab)
        for nombre in ("crm:clientes", "crm:dashboard"):
            with self.subTest(vista=nombre):
                self.assertNotContains(self.client.get(reverse(nombre)), "Clínica Beta Secreta")

    def test_admin_de_django_no_muestra_ni_abre_clientes_ajenos(self):
        self.client.force_login(self.colab)
        lista = self.client.get(reverse("admin:clients_cliente_changelist"))
        self.assertNotContains(lista, "Clínica Beta Secreta", status_code=lista.status_code)
        detalle = self.client.get(reverse("admin:clients_cliente_change", args=[self.b.pk]))
        self.assertNotEqual(detalle.status_code, 200)
        self.assertNotContains(detalle, "Clínica Beta Secreta", status_code=detalle.status_code)

    def test_portal_del_cliente_no_nombra_a_otras_empresas(self):
        self.client.force_login(self.aprobador_a)
        for nombre in PORTAL:
            with self.subTest(vista=nombre):
                r = self.client.get(reverse(nombre))
                self.assertEqual(r.status_code, 200)
                self.assertNotContains(r, "Clínica Beta Secreta")
                self.assertNotContains(r, "Contrato Beta")


class ManipulacionDelIdentificadorDeClienteTests(BaseAislamiento):
    """CP-021: el identificador de cliente enviado por el usuario se ignora o se rechaza."""

    def test_cliente_no_cambia_de_empresa_con_la_sesion(self):
        self.client.force_login(self.aprobador_a)
        sesion = self.client.session
        sesion[SESSION_CLIENT_KEY] = self.b.pk
        sesion.save()
        r = self.client.get(reverse("content:calendario"))
        self.assertEqual(r.wsgi_request.client_id, self.a.pk)

    def test_cliente_no_cambia_de_empresa_con_parametros_de_la_peticion(self):
        self.client.force_login(self.aprobador_a)
        for parametros in ({"cliente": self.b.pk}, {"client_id": self.b.pk}, {"cliente_id": self.b.pk}):
            with self.subTest(parametros=parametros):
                r = self.client.get(reverse("content:metricas"), parametros)
                self.assertEqual(r.wsgi_request.client_id, self.a.pk)
                self.assertNotContains(r, "Clínica Beta Secreta")
                r = self.client.post(reverse("content:aprobacion"), parametros)
                self.assertNotEqual(getattr(r.wsgi_request, "client_id", None), self.b.pk)

    def test_cliente_activo_de_cliente_no_asignado_se_rechaza_y_no_cambia_la_sesion(self):
        self.client.force_login(self.colab)
        self.client.post(reverse("crm:cliente_activo"), {"cliente": self.a.pk})
        r = self.client.post(reverse("crm:cliente_activo"), {"cliente": self.b.pk})
        self.assertEqual(r.status_code, 404)
        self.assertEqual(self.client.session[SESSION_CLIENT_KEY], self.a.pk)

    def test_valores_basura_como_cliente_activo_no_rompen_ni_filtran(self):
        self.client.force_login(self.colab)
        for valor in ("abc", "-1", "0", "9999999999999999999", "1 OR 1=1", "' OR '1'='1"):
            with self.subTest(valor=valor):
                r = self.client.post(reverse("crm:cliente_activo"), {"cliente": valor})
                self.assertIn(r.status_code, (302, 404))
                self.assertNotEqual(self.client.session.get(SESSION_CLIENT_KEY), self.b.pk)

    def test_id_de_cliente_en_sesion_no_asignado_se_descarta(self):
        self.client.force_login(self.colab)
        sesion = self.client.session
        sesion[SESSION_CLIENT_KEY] = self.b.pk
        sesion.save()
        r = self.client.get(reverse("crm:clientes"))
        self.assertNotContains(r, "Clínica Beta Secreta")
        self.assertNotEqual(self.client.session.get(SESSION_CLIENT_KEY), self.b.pk)

    def test_cliente_a_nombre_de_otro_en_el_formulario_de_documentos_se_ignora(self):
        from django.core.files.uploadedfile import SimpleUploadedFile

        self.client.force_login(self.admin)
        self.client.post(
            reverse("crm:cliente_documento_subir", args=[self.a.pk]),
            {"nombre": "Doc A", "tipo": "otro", "cliente": self.b.pk, "archivo": SimpleUploadedFile("a.pdf", b"a")},
        )
        doc = DocumentoCliente.all_objects.get(nombre="Doc A")
        self.assertEqual(doc.cliente_id, self.a.pk)


class CapaDeDatosTests(BaseAislamiento):
    """Aislamiento en el modelo: aunque una vista se equivoque, la consulta no devuelve datos ajenos."""

    def test_el_manager_solo_devuelve_documentos_de_clientes_permitidos(self):
        self._restringir({self.a.pk})
        nombres = set(DocumentoCliente.objects.values_list("nombre", flat=True))
        self.assertEqual(nombres, {"Contrato Alfa"})

    def test_sin_clientes_permitidos_no_se_ve_nada(self):
        self._restringir(set())
        self.assertEqual(DocumentoCliente.objects.count(), 0)

    def test_no_se_guarda_un_documento_en_un_cliente_ajeno(self):
        self._restringir({self.a.pk})
        with self.assertRaises(PermissionDenied):
            DocumentoCliente(cliente=self.b, nombre="Intruso", archivo=ContentFile(b"x", name="i.pdf")).save()
        self.assertEqual(DocumentoCliente.all_objects.filter(nombre="Intruso").count(), 0)

    def test_el_contexto_se_limpia_entre_peticiones(self):
        """Un usuario de cliente no hereda el alcance de la petición anterior."""
        self.client.force_login(self.admin)
        self.client.get(reverse("crm:clientes"))
        self.assertIsNone(get_allowed_client_ids())


class AislamientoDeKPIsTests(BaseAislamiento):
    """Los KPIs y sus mediciones también quedan aislados por cliente."""

    def setUp(self):
        super().setUp()
        from apps.clients.models import KPICliente, MedicionKPI

        self.kpi_a = KPICliente.all_objects.create(cliente=self.a, indicador="seguidores", valor_inicial=100, meta=200)
        self.kpi_b = KPICliente.all_objects.create(cliente=self.b, indicador="seguidores", valor_inicial=7777, meta=9999)
        MedicionKPI.all_objects.create(cliente=self.b, kpi=self.kpi_b, fecha="2026-10-01", valor=8888)

    def test_ficha_propia_no_muestra_kpis_del_otro_cliente(self):
        self.client.force_login(self.colab)
        r = self.client.get(reverse("crm:cliente_ficha", args=[self.a.pk]))
        self.assertContains(r, "Seguidores")
        for secreto in ("7777", "9999", "8888"):
            self.assertNotContains(r, secreto)

    def test_no_se_mide_ni_se_elimina_un_kpi_ajeno(self):
        from apps.clients.models import KPICliente, MedicionKPI

        self.client.force_login(self.admin)
        antes = MedicionKPI.all_objects.count()
        # KPI de B pedido a través de la URL del cliente A: no existe para A
        r1 = self.client.post(reverse("crm:cliente_kpi_medicion", args=[self.a.pk, self.kpi_b.pk]), {"fecha": "2026-10-02", "valor": "1"})
        r2 = self.client.post(reverse("crm:cliente_kpi_eliminar", args=[self.a.pk, self.kpi_b.pk]))
        self.assertEqual((r1.status_code, r2.status_code), (404, 404))
        self.assertEqual(MedicionKPI.all_objects.count(), antes)
        self.assertTrue(KPICliente.all_objects.filter(pk=self.kpi_b.pk).exists())

    def test_colaboradora_no_toca_kpis_de_cliente_no_asignado(self):
        self.client.force_login(self.colab)
        for nombre, args in (("crm:cliente_kpi_crear", [self.b.pk]), ("crm:cliente_kpi_medicion", [self.b.pk, self.kpi_b.pk]), ("crm:cliente_kpi_eliminar", [self.b.pk, self.kpi_b.pk])):
            with self.subTest(vista=nombre):
                self.assertEqual(self.client.post(reverse(nombre, args=args), {}).status_code, 404)

    def test_el_manager_filtra_kpis_y_mediciones_por_cliente(self):
        from apps.clients.models import KPICliente, MedicionKPI

        self._restringir({self.a.pk})
        self.assertEqual(set(KPICliente.objects.values_list("cliente_id", flat=True)), {self.a.pk})
        self.assertEqual(MedicionKPI.objects.count(), 0)

    def test_no_se_guarda_un_kpi_en_un_cliente_ajeno(self):
        from apps.clients.models import KPICliente

        self._restringir({self.a.pk})
        with self.assertRaises(PermissionDenied):
            KPICliente(cliente=self.b, indicador="alcance", valor_inicial=1, meta=2).save()


class IntentoDeAccesoAlPanelTests(BaseAislamiento):
    """CP-019: un usuario cliente no entra al panel; se le informa y el intento queda en la bitácora."""

    def _denegados(self, usuario=None):
        registros = RegistroAuditoria.objects.filter(accion=RegistroAuditoria.Accion.ACCESO_DENEGADO)
        return registros.filter(usuario=usuario) if usuario else registros

    def test_cliente_que_abre_el_panel_vuelve_a_su_portal_con_mensaje(self):
        self.client.force_login(self.aprobador_a)
        r = self.client.get(reverse("crm:dashboard"), follow=True)
        self.assertEqual(r.redirect_chain[-1][0], reverse("content:calendario"))
        self.assertContains(r, "No tienes acceso a esa sección del panel")
        self.assertNotContains(r, "Clínica Beta Secreta")

    def test_cada_intento_del_cliente_queda_en_la_bitacora(self):
        self.client.force_login(self.lector_a)
        self.client.get(reverse("crm:cliente_ficha", args=[self.b.pk]))
        self.client.post(reverse("crm:cliente_activo"), {"cliente": self.b.pk})
        registros = list(self._denegados(self.lector_a).order_by("creado_en"))
        self.assertEqual(len(registros), 2)
        self.assertEqual(registros[0].detalle, f"GET {reverse('crm:cliente_ficha', args=[self.b.pk])}")
        self.assertEqual(registros[1].detalle, f"POST {reverse('crm:cliente_activo')}")
        self.assertEqual(registros[0].entidad, "panel de la agencia")

    def test_colaboradora_en_vista_de_administradora_tambien_queda_registrada(self):
        self.client.force_login(self.colab)
        r = self.client.get(reverse("crm:usuarios"), follow=True)
        self.assertEqual(r.redirect_chain[-1][0], reverse("crm:dashboard"))
        self.assertContains(r, "No tienes acceso a esa sección del panel")
        self.assertEqual(self._denegados(self.colab).count(), 1)

    def test_sin_sesion_se_pide_iniciar_sesion_y_no_se_registra(self):
        r = self.client.get(reverse("crm:dashboard"))
        self.assertIn("login", r["Location"])
        self.assertFalse(self._denegados().exists())

    def test_el_equipo_entra_sin_dejar_registro_de_acceso_denegado(self):
        for usuario in (self.admin, self.colab):
            self.client.force_login(usuario)
            self.assertEqual(self.client.get(reverse("crm:dashboard")).status_code, 200)
        self.assertFalse(self._denegados().exists())

    def test_la_administradora_ve_los_intentos_en_la_auditoria(self):
        self.client.force_login(self.aprobador_a)
        self.client.get(reverse("crm:prospectos"))
        self.client.force_login(self.admin)
        r = self.client.get(reverse("crm:auditoria") + "?accion=denegado")
        self.assertContains(r, "Acceso denegado")
        self.assertContains(r, reverse("crm:prospectos"))
